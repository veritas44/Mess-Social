package github.ankushsachdeva.emojicon;

/**
 * Created by Администратор on 04.01.2016.
 *
 */
public interface EditTextImeBackListener {

    public abstract void onImeBack(EmojiconEditText ctrl, String text);
}